<?php
/*
Template Name: Página para el Mapa
*/
?>

<?php get_header() ?>

<div class="map-container margin-top-fix cf">
	<?php the_content() ?>
</div>

<?php get_footer() ?>